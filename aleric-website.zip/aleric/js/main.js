document.addEventListener('DOMContentLoaded', () => {

  /* ---------- Scroll-to-top button ---------- */
  const scrollTopBtn = document.getElementById('scrollTop');

  if (scrollTopBtn) {
    window.addEventListener('scroll', () => {
      scrollTopBtn.classList.toggle('show', window.scrollY > 500);
    });

    scrollTopBtn.addEventListener('click', () => {
      window.scrollTo({
        top: 0,
        behavior: 'smooth'
      });
    });
  }


  /* ---------- Work stack pagination dots ---------- */
  const workStack = document.getElementById('workStack');
  const workDots = document.getElementById('workDots');

  if (workStack && workDots) {

    const items = workStack.querySelectorAll('.stack-item');

    items.forEach((_, i) => {
      const dot = document.createElement('span');

      if (i === 0) {
        dot.classList.add('active');
      }

      workDots.appendChild(dot);
    });

    const dotEls = workDots.querySelectorAll('span');

    const observer = new IntersectionObserver((entries) => {

      entries.forEach(entry => {

        const idx = Array.from(items).indexOf(entry.target);

        if (
          entry.isIntersecting &&
          entry.intersectionRatio > 0.55
        ) {
          dotEls.forEach(d => {
            d.classList.remove('active');
          });

          dotEls[idx]?.classList.add('active');
        }

      });

    }, {
      threshold: [0.55],
      rootMargin: '-40% 0px -40% 0px'
    });

    items.forEach(item => observer.observe(item));
  }


  /* ---------- Testimonial slider ---------- */
  const track = document.getElementById('testiTrack');
  const indexLabel = document.getElementById('testiIndex');
  const progressFill = document.getElementById('progressFill');

  if (track) {

    const cards = track.querySelectorAll('.testi-card');
    const total = cards.length;

    let current = 0;
    let timer;


    function goTo(i) {

      current = (i + total) % total;

      track.style.transform =
        `translateX(-${current * 100}%)`;

      if (indexLabel) {
        indexLabel.textContent =
          String(current + 1).padStart(2, '0');
      }

      if (progressFill) {
        progressFill.style.width =
          `${((current + 1) / total) * 100}%`;
      }
    }


    function startAuto() {
      timer = setInterval(() => {
        goTo(current + 1);
      }, 4500);
    }


    function stopAuto() {
      clearInterval(timer);
    }


    goTo(0);
    startAuto();


    const viewport =
      track.closest('.testi-viewport');

    if (viewport) {

      viewport.addEventListener(
        'mouseenter',
        stopAuto
      );

      viewport.addEventListener(
        'mouseleave',
        startAuto
      );
    }
  }


  /* ---------- Mobile nav toggle ---------- */
  const menuToggle =
    document.getElementById('menuToggle');

  const mainNav =
    document.getElementById('mainNav');


  if (menuToggle && mainNav) {

    menuToggle.addEventListener('click', () => {

      mainNav.classList.toggle('open');

      const navList =
        mainNav.querySelector('.nav-list');


      if (navList) {

        navList.style.display =
          navList.style.display === 'flex'
            ? 'none'
            : 'flex';

        navList.style.flexDirection =
          'column';

        navList.style.position =
          'absolute';

        navList.style.top =
          '100%';

        navList.style.left =
          '0';

        navList.style.right =
          '0';

        navList.style.background =
          '#fff';

        navList.style.padding =
          '20px 24px';

        navList.style.gap =
          '18px';

        navList.style.borderBottom =
          '1px solid #e5e5e2';
      }

    });
  }


  /* ---------- Search toggle ---------- */
  const searchToggle =
    document.getElementById('searchToggle');


  if (searchToggle) {

    searchToggle.addEventListener('click', () => {

      const q =
        prompt('Search the site:');

      if (q) {

        alert(
          `Showing results for "${q}" — search isn't wired to a backend yet.`
        );

      }

    });

  }

});